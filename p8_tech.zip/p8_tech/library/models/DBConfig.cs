namespace models {
    public class DBConfig {
        public string host { get; set; }
        public int port { get; set; }
        public string db { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}